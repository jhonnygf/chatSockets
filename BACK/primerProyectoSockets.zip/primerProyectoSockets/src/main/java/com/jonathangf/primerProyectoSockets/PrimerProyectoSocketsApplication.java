package com.jonathangf.primerProyectoSockets;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PrimerProyectoSocketsApplication {

	public static void main(String[] args) {
		SpringApplication.run(PrimerProyectoSocketsApplication.class, args);
	}

}
